import { Component, OnInit, ElementRef } from '@angular/core';

@Component({
  selector: 'transfer-page',
  templateUrl: './transfer-page.component.html',
  styleUrls: ['./transfer-page.component.css']
})
export class TransferPageComponent implements OnInit {

  public nexStep(){
  
  }


  constructor() { }

  ngOnInit() {
  }

}
